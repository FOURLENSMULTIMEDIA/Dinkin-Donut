DINK DIFFERENT · SOCIAL MEDIA KIT

Instagram feed (1080 x 1350)
  post-open        Open play announcement
  post-rule        "Rule No. 1 · Shake hands at the net." quote post
  post-honours     Honours Board winners template (replace names in Canva or ask Claude)
Instagram stories (1080 x 1920)
  story-tonight    Tonight 8 PM, with the queue QR code
  story-clubcard   Club Card: play six, the seventh is on the club
Story highlight covers (1080 x 1920, icon centred for the circle crop)
  hl-open · hl-academy · hl-shop · hl-card · hl-cup
Profile picture  profile (1080 x 1080). Instagram crops it to a circle.
WhatsApp group icon  whatsapp-icon (640 x 640)
Facebook cover  facebook-cover (1640 x 624). The left side stays clear for the profile picture.

Captions: calm and warm, no all-caps shouting, no more than one emoji.
Hashtags: #DinkDifferent #DohaPickleball #Pickleball #OpenPlay #Doha
