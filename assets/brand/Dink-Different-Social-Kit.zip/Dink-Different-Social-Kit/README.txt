DINK DIFFERENT · SOCIAL MEDIA KIT · EDITION II

grid-posts-1x1/      Nine square posts (1080 x 1080) planned as one 3 x 3 profile grid.
                     Post them in REVERSE order (g9 first, g1 last) so g1 sits top-left.
                     Key content sits in the centre 810 px, so they also look right in
                     Instagram's newer 3:4 grid crop.
                     g1 The Club · g2 Open Play · g3 Rule No. 1
                     g4 Club Card · g5 The Crest (centre) · g6 The Invitational
                     g7 Honours Board (template: replace names) · g8 Clubhouse Tee · g9 Academy
stories/             Five stories (1080 x 1920). Top 250 px and bottom 300 px kept calm for Instagram's UI.
                     s1 Tonight (QR to the queue) · s2 Club Card · s3 The First Serve
                     s4 The Clubhouse Collection · s5 Soft Hands Academy
highlight-covers/    Five covers, icon centred for the circle crop.
profile-and-covers/  Profile picture 1080 x 1080, WhatsApp group icon, Facebook cover 1640 x 624.
reclub/              Reclub club cover: 16:9 (1920 x 1080) and 3:1 banner (1500 x 500).
                     Everything important is centred, so either crop works.

Captions: calm and warm, no all-caps shouting, one emoji at most.
Hashtags: #DinkDifferent #DohaPickleball #Pickleball #OpenPlay #Doha
