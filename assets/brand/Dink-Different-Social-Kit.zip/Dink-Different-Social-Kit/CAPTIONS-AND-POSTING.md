# Dink Different · Social media kit · Edition III (beige & navy)

**Formats**
- `carousel-opening-soon/`: 7 square (1:1, 1080 × 1080) slides. Upload them in number order as one carousel. Slides 1, 6 and 7 are animated (MP4); the others are stills (PNG).
- `grid-posts-1x1/`: nine square posts that form a navy-and-beige checkerboard on your profile. Post them in reverse (g9 first, g1 last) so the crest sits top-left. All key content stays in the centre, so it also looks right in Instagram's 3:4 grid.
- `stories-animated/`: four animated stories, 1080 × 1920. Add music inside Instagram.
- `*-cover-frame.jpg`: the last frame of each animation, to use as the cover.
- `highlight-covers/`, `profile-and-covers/` and `reclub/` are kept from the kit, including the navy Reclub covers.

---

## Carousel · Opening Soon

**Caption**
> Something different is coming to Doha.
>
> Dink Different is a pickleball club run the old-fashioned way: open play for every level, fair games, and a handshake at the net. Swipe to see what’s inside.
>
> DINK DIFFERENT is using Reclub to organize activities! Use the club code AX3ND or tap the link below to join.
> https://reclub.co/clubs/@dink-different-cyuiuw?at=N7OIK377
>
> #DinkDifferent #DohaPickleball #PickleballQatar #Pickleball #OpenPlay #Doha #Qatar

Links aren't clickable in Instagram captions, so put the Reclub link in your **bio** (or a Linktree with the website), and add a **link sticker** to the Reclub story.

## Stories
1. **Opening soon:** add a countdown sticker for opening night.
2. **Reclub (club code AX3ND + QR):** add a link sticker to https://reclub.co/clubs/@dink-different-cyuiuw?at=N7OIK377
3. **Follow the club:** add an @mention sticker for @dinkindonutqa.
4. **What's inside:** add a poll: "Which are you most excited for?"

## Grid posts · captions
- g1 The Crest: *Dink Different Pickleball Club · Doha, Qatar. Est. MMXXVI.*
- g2 Opening soon: *Opening soon in Doha. Join us on Reclub with club code AX3ND (link in bio).*
- g3 Rule No. 1: *Rule No. 1. Shake hands at the net.*
- g4 Reclub code: *DINK DIFFERENT is using Reclub to organize activities! Use the club code AX3ND or tap the link in our bio to join.*
- g5 The wordmark: *Play well. Dink different.*
- g6 Club Card: *Play six. The seventh is on the club. Free to join.*
- g7 The Invitational: *A gentle war. Doubles for every level, final to fifteen. Date soon.*
- g8 Sporting Club Tee: *The Sporting Club Tee, from the Clubhouse Collection.*
- g9 Academy: *Soft hands, quiet wrist. Soft Hands Academy, seven days free.*

**Suggested rhythm:** the carousel first, then one grid post a day at 7:30 PM Doha time, and a story every day (rotate the four).
