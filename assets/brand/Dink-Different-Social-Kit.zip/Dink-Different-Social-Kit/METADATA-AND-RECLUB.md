# Dink Different · Social metadata, Reclub copy & meets

Copy and paste as written. Placeholders are in [brackets].

---

## 1 · Profiles

**Name (all platforms):** Dink Different · Pickleball Club
**Short name:** Dink Different
**Tagline:** Play well. Dink different.
**Location:** Doha, Qatar
**Category:** Sports Club · Pickleball
**Website:** dinkindonut.asia
**Reclub club code:** AX3ND · https://reclub.co/clubs/@dink-different-cyuiuw?at=N7OIK377
**Profile picture:** `profile-and-covers/profile.png` (the Different D on navy)
**Covers:** `profile-and-covers/facebook-cover.png`, plus Reclub covers in `reclub/`

### Instagram bio (150 characters max)
```
Dink Different · Pickleball Club
A pickleball club, the old-fashioned way.
Open play · DUPR · Doha, Qatar
Reclub code AX3ND ↓
```
**Link in bio:** the Reclub link above. If you use Linktree, list in this order: Join on Reclub · The First Serve · Club Card · Shop · Soft Hands Academy.
**Highlights (in order):** Open Play · Academy · Shop · Club Card · Invitational (covers in `highlight-covers/`)

### Facebook page
- **Page name:** Dink Different Pickleball Club
- **Username:** @dinkdifferent (claim it if it's free)
- **Intro (101 characters max):** A pickleball club in Doha, run the old-fashioned way. Open play for every level. Join on Reclub: AX3ND.
- **About:** Dink Different is a pickleball club in Doha, Qatar for players of every level. Our open play nights run like an old members' club: a live queue on your phone, fair level-balanced games, the Honours Board at the end of the night, and a handshake at the net. We also host DUPR rated games, the Invitational tournament and Soft Hands Academy coaching. Every session is organised on Reclub: club code AX3ND.

### TikTok / Threads bio (80 characters)
```
Pickleball, the old-fashioned way. Doha 🇶🇦 Reclub: AX3ND
```

### WhatsApp Business / Community
- **Name:** Dink Different · Pickleball Club
- **About:** Play well. Dink different.
- **Description:** Open play, DUPR games and the Invitational in Doha. Join every session on Reclub with club code AX3ND.
- **Group icon:** `profile-and-covers/whatsapp-icon.png`

---

## 2 · Hashtag sets (rotate, use 5 to 8 per post)
- **Core:** #DinkDifferent #DohaPickleball #PickleballQatar #Pickleball #OpenPlay
- **Local:** #Doha #Qatar #QatarSports #DohaSports #ThingsToDoInDoha
- **Play:** #PickleballLife #DUPR #PickleballCommunity #DinkShot #SoftHands
- **Style:** #OldMoney #ClubhouseStyle #PickleballStyle #TennisClubAesthetic

---

## 3 · Alt text (paste under Advanced settings → Accessibility)
- **Carousel 1, Opening soon:** Navy slide with the Dink Different monogram, two D's back to back with a ball over the net, and the words "Opening soon" in cream and brass.
- **Carousel 2, What is it:** Beige slide reading "A pickleball club from Doha, Qatar" with a short description of the club.
- **Carousel 3, On court:** Navy slide listing the live queue, fair games, DUPR rated games and the Honours Board.
- **Carousel 4, Off court:** Beige slide listing the Club Card, Soft Hands Academy, the Clubhouse Collection and the Invitational.
- **Carousel 5, Follow:** Navy slide with Instagram @dinkindonutqa, Reclub code AX3ND, WhatsApp and website.
- **Carousel 6, Reclub:** Beige slide with the Reclub club code A X 3 N D and a QR code to join.
- **Carousel 7, See you on court:** Navy closing slide with the monogram.
- **Grid posts:** "Dink Different [post name] in navy and beige, in the club's serif lettering."

---

## 4 · Reclub club page

**Club name:** DINK DIFFERENT
**Tagline:** Play well. Dink different.

**Short description (first line people see):**
> A pickleball club in Doha, run the old-fashioned way. Open play for every level, fair games, and a handshake at the net.

**Full description:**
> Welcome to Dink Different, Doha's pickleball club with old-school manners.
>
> Every session is open to all levels. Scan in at the court and our live queue calls you to your game, on your phone and on the court TV. Smart matching keeps games fair and nobody sits out twice. Winners stay for two games, then everyone rotates. At the end of the night the top three go on the Honours Board.
>
> **What to bring:** court shoes, water and a paddle (spares available). Whites are welcome, never required.
>
> **The club rules:** shake hands at the net · call your lines kindly · mix levels, everyone plays.
>
> **Members' perks:** the Club Card (play six, the seventh is on the club), DUPR rated games, Soft Hands Academy coaching and the Clubhouse Collection.
>
> Questions: WhatsApp +974 3076 3431 · Instagram @dinkindonutqa · dinkindonut.asia

**Joining & cancellation (paste into Reclub's policy field):**
> Book your place on Reclub. If you can't make it, cancel at least 12 hours before so someone on the waitlist can play. Pay at check-in or as shown on the meet. Late cancellations and no-shows may lose priority booking.

---

## 5 · Meets: names and descriptions

Times are suggestions; set your own. [Fee] means your price.

### The First Serve · Opening Night
*One time only · All levels · 3 hours · 48 places*
> Our very first night on court. Forty-eight numbered places, and each player gets a Founding Dinker seal made from their name. Open play for every level, the first Honours Board crowned at the end of the night, and a few surprises. Whites welcome. Reserve early; it won't come again. [Fee]

### Club Night · Open Play
*Weekly · All levels · 8 PM till late*
> The heart of the club. Scan in at the court and the queue calls you to your game. Fair, level-balanced doubles; winners stay two games, then everyone rotates. The top three go on the Honours Board. Every paid session earns a Club Card stamp. [Fee]

### Friday Whites
*Monthly · All levels · Social*
> Our dress-code night: come in white, old tennis-club style. Open play, mixed partners, music, and a prize for the best-dressed pair. Pure pickleball, beautifully done. [Fee]

### Soft Hands Clinic · Beginners' Hour
*Weekly · New players & beginners (DUPR under 3.0) · 1 hour*
> New to pickleball, or want cleaner basics? A coached hour on the dink, the third-shot drop and kitchen-line footwork, using our Soft Hands Academy drills. Paddles available. Stay for open play afterwards. [Fee]

### Mixed Doubles Social
*Fortnightly · All levels · 2 hours*
> Every game is mixed doubles: one man and one woman each side, with new partners every round. A relaxed, friendly night that's perfect for meeting the club. [Fee]

### The Members' Ladder
*Weekly · Intermediate & advanced (DUPR 3.0+) · 2 hours*
> Competitive play with a running ladder. Winners move up, and your standing carries over week to week. Tight games, honest line calls and a handshake at the net. [Fee]

### DUPR Rated · Match Play
*Weekly · Intermediate & advanced · Rated*
> Matches that count. Every game is submitted to DUPR, and players are matched by rating for close, competitive play. A free DUPR account is required. [Fee]

### Sunrise Social
*Weekend mornings · All levels · 2 hours*
> Early pickleball before the heat: open play, good coffee and a gentle start to the weekend. Beginners especially welcome. [Fee]

### The Honours Night
*Last session of the month · All levels*
> The month's finale. Open play with points that count toward the Honours Board of the month, and the top three are toasted at the end of the night. [Fee]

### The Invitational
*Tournament · Doubles by level · Date to be announced*
> The Dink Different Invitational. Doubles brackets for beginner, intermediate and advanced players, round robin into knockout, with a final to fifteen. Gold for the champions, and the Club Jersey as the official kit. A gentle war. [Entry fee]
