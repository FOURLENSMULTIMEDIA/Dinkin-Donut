THE PANORAMA CAROUSEL · 5 square slides that join into one continuous canvas

Upload in number order as ONE carousel post (Instagram accepts videos and photos together):
  01-the-mark.mp4            the Different D assembles, the ball leaves the net
  02-dink-different.png
  03-the-old-fashioned-way.png
  04-opening-soon.png
  05-join-the-club.mp4       the ball lands, the Reclub code AX3ND appears

As people swipe, the dotted trajectory of the dink runs across every slide and lands on the last one.
Use 01-the-mark-cover-frame.jpg as the cover.

Caption:
Something different is coming to Doha. Swipe to follow the dink.
DINK DIFFERENT is using Reclub to organize activities! Use the club code AX3ND or tap the link in our bio to join.
#DinkDifferent #DohaPickleball #PickleballQatar #Pickleball #OpenPlay #Doha #Qatar
