DINK DIFFERENT · COURT KIT

Print-ready PDFs at the exact size (paper at 300 dpi), plus PNG previews.

01  QR stand · A4 portrait          "Scan to join the queue". Fits an A4 acrylic stand at the court entrance.
02  Check-in tent · A5 front        For a double-sided A5 acrylic stand at the check-in table.
03  Check-in tent · A5 back         Reclub club code AX3ND and QR to book the next night.
04–06 Court signs: replaced by the new laminate signs in D-Court-Signs-A4-Laminate
07  The Club Rules · A3             For the fence, the wall, or a framed easel.
08  The Honours Board · A3          Write tonight's winners in with a gold or white paint marker.
09  Roll-up banner · 85 x 200 cm    With the Reclub code, QR, @dinkdifferentqa and WhatsApp.
10  Step-and-repeat · 250 x 200 cm  A logo wall for player photos. Ask for matte vinyl so flash doesn't glare.
11  Reserved · The Committee · A6   For the organisers' table.

Printer notes
- Matte finish throughout. Navy #1D2840 · Brass #9C7A45 (metallic gold ink or foil for the plaques if budget allows) · Ivory #F4EFE3.
- Foam board (5 mm) for the court plaques and rules board. 350 gsm silk for the tent cards.
- Banners: ask the printer for a 3 cm bleed. Logos sit well inside the safe area.
- QR codes go to dinkindonut.asia/queue (check-in) and your Reclub club page. Test-scan the first print.
