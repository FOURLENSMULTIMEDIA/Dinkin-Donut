IN-GAME KIT · what's on court during play (print at 100%, PDFs are exact size at 300 dpi)
ig-01 Court scoreboard · A3 landscape · laminate it and write scores with a dry-erase marker
ig-02 Score sheet · A4 · host backup if the queue or wifi is down
ig-03 The Kitchen · A4 landscape · zip-tie to the net post or fence
ig-04 Call the score · A5 · one per court, by the net post
ig-05 On court (etiquette) · A5
ig-06 Paddle stack · A4 · backup system if the live queue is down
ig-07 Refresh station · A5 · water and towels table
ig-08 Club balls · A6 · label for the ball bin
