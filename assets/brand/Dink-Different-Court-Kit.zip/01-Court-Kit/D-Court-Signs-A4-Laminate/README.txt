COURT SIGNS · A4 LANDSCAPE · READY TO LAMINATE

Just the court number and the check-in QR code. Courts 1–6 in navy (main) and beige.
Easiest: print ALL-COURTS-1-6-navy-print-this.pdf (six pages, one per court).
- Print at 100% / actual size on 200–250 gsm matte paper, then laminate in a matte pouch to avoid glare.
- The frame sits 10 mm in from the edge, so nothing important is trimmed.
- The QR opens dinkindonut.asia/queue. Scan the first print to check it.
