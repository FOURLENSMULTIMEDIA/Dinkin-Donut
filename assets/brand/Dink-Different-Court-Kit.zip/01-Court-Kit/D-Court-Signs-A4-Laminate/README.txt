COURT SIGNS · A4 LANDSCAPE · READY TO LAMINATE

Courts 1–6 in navy (main) and beige (alternative). Each sign: the court emblem, "Court One" (and so on), the three court rules and a QR code to check in to the queue.

Easiest: print ALL-COURTS-1-6-navy-print-this.pdf. It has six pages, one per court.
- Print at 100% / "actual size" on 200–250 gsm matte paper, then laminate (125 micron, matte pouch if possible to avoid glare).
- The frame sits 10 mm inside the edge, so nothing important is trimmed.
- Zip-tie through punched corners to the fence or net post, or slide into an A4 landscape acrylic frame.
- Scan the QR on the first print to check it opens the queue.
