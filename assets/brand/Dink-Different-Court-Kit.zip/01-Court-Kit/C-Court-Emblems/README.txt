Court emblems 1–6 in navy and beige. SVG (vector, outlined, any size) and PNG 3000 x 3000 with transparent corners.
Use them on court signs, the net post, the TV, stickers or floor decals.
