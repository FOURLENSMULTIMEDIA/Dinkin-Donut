Court emblems 1–6, navy and beige: SVG (vector, any size) and PNG 3000 x 3000 with transparent corners.
sticker-sheet-A4-90mm.pdf: six 90 mm round stickers on one A4 sheet. Print on matte vinyl sticker paper and cut on the dashed line.
Use them on the net post, paddle racks, the TV frame or floor decals.
