DINK DIFFERENT · BRAND KIT · EDITION I
Pickleball Club · Doha · Est. MMXXVI · "Play well. Dink different."

LOGO
  mark            The Different D: two D's back to back, one flipped, forming a
                  court with a brass net and a ball dinking over it.
  badge-navy      Primary badge, on light backgrounds (also logo.svg)
  badge-beige     Badge for beige and light kit
  wordmark        Mark + "Dink" (Fraunces 800) + "Different" (Fraunces italic, brass)
  wordmark-stacked  For signage, posters and kit backs
  All lettering is outlined: it looks identical everywhere, no fonts needed.
  Clear space: one D-bowl on every side. Minimum: mark 24 px / 10 mm.
  Never recolour, stretch, outline or add effects.

COLOUR
  Oatmeal   #EDE4D3  page background
  Ivory     #F4EFE3  text on navy
  Linen     #E3D8C3  panels
  Stone     #D6C8AC  lines
  Camel     #B89B72  leather, kit
  Brass     #9C7A45  the only accent
  Club Navy #1D2840  ink, deep panels
  Ball      #E3CF7E  the ball only
  Oxblood   #8E2F2F  warnings / losses

TYPE
  Display: Fraunces (free, Google Fonts) with SOFT 100. Headlines 800,
           brass swash italic for the second thought.
  Text:    DM Sans 400/500/700; small labels in caps, tracking .3em

VOICE
  Heritage. Warmth. Restraint. Classic, never "exclusive". Pickleball, never tennis.

NAMES
  The Honours Board · The Invitational · Club Card · Club Pass · The Heirloom (1 of 20)
  Soft Hands Academy · Courtcall (separate neutral brand for other clubs)

Full guide: https://dinkindonut.asia/brand
