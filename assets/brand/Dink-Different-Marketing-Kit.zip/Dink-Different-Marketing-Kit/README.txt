DINK DIFFERENT · MARKETING KIT

Print (PDF + PNG)
  flyer-a4         The First Serve pre-registration flyer, A4, QR to /first-serve
  checkin-a5       "Scan to join the queue" sign for the check-in table, A5, QR to /queue
  rollup-banner    Roll-up banner, 85 x 200 cm. Ask the printer to scale to size; artwork is vector-sharp at this ratio.
  bizcard-print    Organiser business card, 3.5 x 2 in, front + back. Ask for 400gsm matte, rounded corners.
Digital
  email-header     1200 x 400 for newsletters and WhatsApp broadcasts

Printer notes: colours are Club Navy #1D2840, Brass #9C7A45 (or a metallic gold foil), Oatmeal #EDE4D3.
