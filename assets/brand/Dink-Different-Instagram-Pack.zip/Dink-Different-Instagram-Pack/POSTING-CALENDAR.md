# Dink Different · Instagram content pack

**What's inside**
- `stories-animated/`: five animated stories, 1080 × 1920 MP4, about 10 seconds each. Add music in Instagram. Calm piano or jazz suits the brand; avoid anything shouty.
- `carousel-1-club-rules/`, `carousel-2-a-night-at-the-club/`, `carousel-3-clubhouse-collection/`, `carousel-4-academy-tips/`: square 1080 × 1080 carousels. Each mixes animated slides (MP4) and still slides (PNG). Upload the files in number order; Instagram carousels accept videos and photos together.
- Grid posts: the nine square posts from the social kit (`grid-posts-1x1`). Together they build the 3 × 3 profile grid.
- `*-cover.jpg`: the last frame of each animation. Use it as the cover when Instagram asks.

**Rhythm:** three feed posts a week (Mon, Wed, Fri at 7:30 PM Doha time, just before evening play) and one story every day. Post the grid posts in reverse (g9 first), with the carousels in between.

---

## Two-week calendar

| Day | Feed | Story |
|---|---|---|
| Mon · W1 | g9 · Soft Hands Academy | story5 · Academy |
| Tue | n/a | story1 · Tonight (QR) |
| Wed | **Carousel 1 · The Club Rules** | story2 · Club Card |
| Thu | g8 · Sporting Club Tee | story1 · Tonight (QR) |
| Fri | g7 · The Honours Board (add real winners) | story3 · The First Serve |
| Sat | n/a | story4 · Clubhouse Collection |
| Sun | g6 · The Invitational | story2 · Club Card |
| Mon · W2 | **Carousel 2 · A Night at the Club** | story1 · Tonight (QR) |
| Tue | g5 · The Crest | story5 · Academy |
| Wed | **Carousel 3 · The Clubhouse Collection** | story4 · Clubhouse Collection |
| Thu | g4 · The Club Card | story1 · Tonight (QR) |
| Fri | **Carousel 4 · Three fixes for a softer dink** | story3 · The First Serve |
| Sat | g3 · Rule No. 1 | story2 · Club Card |
| Sun | g2 · Open Play, then g1 · The Club | story1 · Tonight (QR) |

---

## Captions (ready to paste)

**Carousel 1 · The Club Rules**
> Five rules. One club.
> I. Shake hands at the net. II. Call your lines, kindly. III. Winners stay two games. IV. Mix levels, everyone plays. V. Whites welcome, everyone in.
> Save this for your first night. 🎾
> #DinkDifferent #DohaPickleball #Pickleball #OpenPlay #Doha

**Carousel 2 · A Night at the Club**
> 7:15 nets up. 7:45 soft hands first. 8:00 scan in and we call you. 11:50 the Honours Board is crowned.
> Every week, 8 PM till late. Join the queue from the link in bio.
> #DinkDifferent #DohaPickleball #PickleballNight #OpenPlay

**Carousel 3 · The Clubhouse Collection**
> Drop 02. Five heavyweight cotton tees cut like the old lawn and racquet clubs: Sporting Club, Members, Court Stripe, Rule No. 1, Court No. 2.
> 240 gsm, garment-dyed, small runs. Shop from the link in bio.
> #DinkDifferent #PickleballStyle #OldMoney #ClubhouseCollection

**Carousel 4 · Three fixes for a softer dink**
> Lift from the shoulder. Apex on your side. Grip at a three.
> Twenty animated lessons like this in Soft Hands Academy, seven days free. Link in bio.
> #DinkDifferent #PickleballTips #DinkShot #SoftHands

**Grid posts**
- g1 The Club: *A pickleball club, the old-fashioned way. Est. MMXXVI.*
- g2 Open Play: *Paddles up. Every week, 8 PM till late. Every level welcome.*
- g3 Rule No. 1: *Rule No. 1. Shake hands at the net.*
- g4 Club Card: *Play six. The seventh is on the club. Free to join, link in bio.*
- g5 The Crest: *Dink Different Pickleball Club · Doha.*
- g6 The Invitational: *A gentle war. Doubles for every level, final to fifteen. Date soon.*
- g7 The Honours Board: *Tonight's winners. Congratulations to [Gold], [Silver] and [Bronze].*
- g8 Sporting Club Tee: *The Sporting Club Tee. Drop 02, link in bio.*
- g9 Academy: *Soft hands, quiet wrist. Seven days free.*

**Story stickers to add in Instagram:** a link sticker (queue, Club Card, First Serve, shop or Academy), a countdown sticker on The First Serve, and a poll on the Clubhouse story ("Which tee?").

**House rules for captions:** warm and calm, no all-caps, one emoji at most, always end on what to do next.
